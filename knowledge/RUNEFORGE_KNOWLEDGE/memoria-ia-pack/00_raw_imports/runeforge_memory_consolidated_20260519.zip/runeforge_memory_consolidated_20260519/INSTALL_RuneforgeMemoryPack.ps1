# INSTALL_RuneforgeMemoryPack.ps1
# Ejecutar desde la carpeta donde estén los archivos generados.
# No toca backend. No borra memoria previa. Crea backup de archivos existentes.

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

Write-Host "[RUNEFORGE_MEMORY_PACK_INSTALL][$ts]"

$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetRoot = "C:\RUNEFOGE_PRO\memoria-ia-pack"
$RawDir = Join-Path $TargetRoot "00_raw_imports"
$NormDir = Join-Path $TargetRoot "01_normalized"
$ProjectsDir = Join-Path $NormDir "PROJECTS"
$RulesDir = Join-Path $TargetRoot "02_rules"
$LogsDir = Join-Path $TargetRoot "03_logs"
$ScriptsDir = Join-Path $TargetRoot "scripts"
$BackupDir = Join-Path $TargetRoot ("backups\install_" + $stamp)

$Required = @(
  "MASTER_MEMORY_MERGED.md",
  "FACTS_CANONICAL_MERGED.yaml",
  "CONFLICTS_DETECTED.yaml",
  "MERGE_REPORT.md"
)

foreach ($file in $Required) {
  $p = Join-Path $SourceDir $file
  if (-not (Test-Path -LiteralPath $p)) {
    throw "Falta archivo requerido junto al instalador: $file"
  }
}

New-Item -ItemType Directory -Force -Path $TargetRoot,$RawDir,$NormDir,$ProjectsDir,$RulesDir,$LogsDir,$ScriptsDir,$BackupDir | Out-Null

$CopyMap = @{
  "MASTER_MEMORY_MERGED.md"     = Join-Path $NormDir "MASTER_MEMORY.md"
  "FACTS_CANONICAL_MERGED.yaml" = Join-Path $NormDir "FACTS_CANONICAL.yaml"
  "CONFLICTS_DETECTED.yaml"     = Join-Path $NormDir "CONFLICTS.yaml"
  "MERGE_REPORT.md"             = Join-Path $LogsDir ("merge_log_" + (Get-Date -Format "yyyy-MM-dd") + ".md")
}

foreach ($srcName in $CopyMap.Keys) {
  $src = Join-Path $SourceDir $srcName
  $dst = $CopyMap[$srcName]
  if (Test-Path -LiteralPath $dst) {
    Copy-Item -LiteralPath $dst -Destination (Join-Path $BackupDir ([IO.Path]::GetFileName($dst) + "." + $stamp + ".bak")) -Force
  }
  Copy-Item -LiteralPath $src -Destination $dst -Force
}

$Manifest = [ordered]@{
  ts = (Get-Date).ToString("o")
  status = "RUNEFORGE_MEMORY_PACK_INSTALLED"
  target_root = $TargetRoot
  normalized = $NormDir
  files = $CopyMap
  backend = "NO_TOCADO"
  secrets = "NO_INCLUIDOS"
}

$ManifestPath = Join-Path $LogsDir ("install_manifest_" + $stamp + ".json")
$Manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ManifestPath -Encoding utf8BOM -Force

Write-Host ""
Write-Host "[SUMMARY]" -ForegroundColor Green
[pscustomobject]@{
  Estado = "RUNEFORGE_MEMORY_PACK_INSTALLED"
  TargetRoot = $TargetRoot
  Master = (Join-Path $NormDir "MASTER_MEMORY.md")
  Facts = (Join-Path $NormDir "FACTS_CANONICAL.yaml")
  Conflicts = (Join-Path $NormDir "CONFLICTS.yaml")
  Log = (Join-Path $LogsDir ("merge_log_" + (Get-Date -Format "yyyy-MM-dd") + ".md"))
  Manifest = $ManifestPath
  Backend = "NO_TOCADO"
} | Format-List
